// TODO (sergeyk): effect should not be dependent on phase. wasted memcpy.

#include <vector>

#include "caffe/layers/dropout_channel_layer.hpp"
#include "caffe/util/math_functions.hpp"

namespace caffe {

template <typename Dtype>
void DropoutChannelLayer<Dtype>::LayerSetUp(const vector<Blob<Dtype>*>& bottom,
      const vector<Blob<Dtype>*>& top) {
  NeuronLayer<Dtype>::LayerSetUp(bottom, top);
  threshold_ = this->layer_param_.dropout_channel_param().dropout_channel_ratio();
  dropout_test_ = this->layer_param_.dropout_channel_param().dropout_channel_test();
  DCHECK(threshold_ > 0.);
  DCHECK(threshold_ < 1.);
  CHECK(bottom[0]->num() == bottom[1]->num())
      << "number of examples should be the same";
  CHECK(bottom[0]->channels() == bottom[1]->channels())
      << "channel of examples should be the same";

  scale_ = 1. / (1. - threshold_);
  //uint_thres_ = static_cast<unsigned int>(UINT_MAX * threshold_);

  num_ = bottom[0]->num();
  channels_ = bottom[0]->channels();
}

template <typename Dtype>
void DropoutChannelLayer<Dtype>::Reshape(const vector<Blob<Dtype>*>& bottom,
      const vector<Blob<Dtype>*>& top) {
  NeuronLayer<Dtype>::Reshape(bottom, top);
  // Set up the cache for random number generation
  // ReshapeLike does not work because rand_vec_ is of Dtype uint
  //rand_vec_.Reshape(num_,channels_,1,1);
}

template <typename Dtype>
void DropoutChannelLayer<Dtype>::Forward_cpu(const vector<Blob<Dtype>*>& bottom,
    const vector<Blob<Dtype>*>& top) {
  const Dtype* bottom_data = bottom[0]->cpu_data();
  const Dtype* bottom_mask_data = bottom[1]->cpu_data();
  Dtype* top_data = top[0]->mutable_cpu_data();
  //unsigned int* mask = rand_vec_.mutable_cpu_data();
  const int count = num_*channels_;
  int iFactor = bottom[0]->width()*bottom[0]->height();

  if (this->phase_ == TRAIN) {
    // Create random numbers
    //caffe_rng_bernoulli(count, 1. - threshold_, mask);
    for (int i = 0; i < count; ++i) {    
      const int ic = (i / iFactor) % channels_;
      const int in = (i / iFactor) / channels_;
      top_data[i] = bottom_data[i] * bottom_mask_data[in * channels_ + ic] * scale_;
    }
  } else {
    caffe_copy(bottom[0]->count(), bottom_data, top_data);
  }
}

template <typename Dtype>
void DropoutChannelLayer<Dtype>::Backward_cpu(const vector<Blob<Dtype>*>& top,
    const vector<bool>& propagate_down,
    const vector<Blob<Dtype>*>& bottom) {
  if (propagate_down[0]) {
    const Dtype* top_diff = top[0]->cpu_diff();
    Dtype* bottom_diff = bottom[0]->mutable_cpu_diff();
    const Dtype* bottom_mask_data = bottom[1]->cpu_data();

    if (this->phase_ == TRAIN) {
      //unsigned int* mask = rand_vec_.mutable_cpu_data();
      const int count = num_*channels_;
      int iFactor = bottom[0]->width()*bottom[0]->height();

      for (int i = 0; i < count; ++i) {
        const int ic = (i / iFactor) % channels_;
        const int in = (i / iFactor) / channels_;
        bottom_diff[i] = top_diff[i] * bottom_mask_data[in * channels_ + ic] * scale_;
      }
    } else {
      caffe_copy(top[0]->count(), top_diff, bottom_diff);
    }
  }
}


#ifdef CPU_ONLY
STUB_GPU(DropoutChannelLayer);
#endif

INSTANTIATE_CLASS(DropoutChannelLayer);
REGISTER_LAYER_CLASS(DropoutChannel);

}  // namespace caffe
