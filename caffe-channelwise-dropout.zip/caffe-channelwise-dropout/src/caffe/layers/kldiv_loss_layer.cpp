#include <vector>

#include "caffe/layers/kldiv_loss_layer.hpp"
#include "caffe/util/math_functions.hpp"

namespace caffe {

template <typename Dtype>
void KLDivLossLayer<Dtype>::Reshape(
  const vector<Blob<Dtype>*>& bottom, const vector<Blob<Dtype>*>& top) {
  LossLayer<Dtype>::Reshape(bottom, top);
  CHECK_EQ(bottom[0]->count(1), bottom[1]->count(1))
      << "Inputs must have the same dimension.";
  loss_.ReshapeLike(*bottom[0]);
}

template <typename Dtype>
void KLDivLossLayer<Dtype>::Forward_cpu(const vector<Blob<Dtype>*>& bottom,
    const vector<Blob<Dtype>*>& top) {
  int count = bottom[0]->count();
  const Dtype* target_data = bottom[0]->cpu_data();
  const Dtype* input_data = bottom[1]->cpu_data();
  Dtype* loss_data = loss_.mutable_cpu_data();

  caffe_log(count, target_data, loss_data);

  Dtype loss_kldiv = Dtype(0);
  for (int i = 0;i < count; ++i) {
    loss_kldiv += target_data[i] * (loss_data[i] - input_data[i]);
  }

  top[0]->mutable_cpu_data()[0] = loss_kldiv / count;
}

template <typename Dtype>
void KLDivLossLayer<Dtype>::Backward_cpu(const vector<Blob<Dtype>*>& top,
    const vector<bool>& propagate_down, const vector<Blob<Dtype>*>& bottom) {
  int count = bottom[0]->count();
  const Dtype* target_data = bottom[0]->cpu_data();
  Dtype* input_diff = bottom[1]->mutable_cpu_diff();

  for (int i = 0;i < count;++i) {
    input_diff[i] = target_data[i] / count;
  }
}

#ifdef CPU_ONLY
STUB_GPU(KLDivLossLayer);
#endif

INSTANTIATE_CLASS(KLDivLossLayer);
REGISTER_LAYER_CLASS(KLDivLoss);

}  // namespace caffe
