#include <algorithm>
#include <vector>

#include "caffe/layers/mean_example_layer.hpp"
#include "caffe/util/math_functions.hpp"

namespace caffe {

template <typename Dtype>
void MeanExampleLayer<Dtype>::LayerSetUp(const vector<Blob<Dtype>*>& bottom,
      const vector<Blob<Dtype>*>& top) {
  num_ = bottom[0]->num();
  channels_ = bottom[0]->channels();
  height_ = bottom[0]->height();
  width_ = bottom[0]->width();
}

template <typename Dtype>
void MeanExampleLayer<Dtype>::Reshape(const vector<Blob<Dtype>*>& bottom,
      const vector<Blob<Dtype>*>& top) {
    top[0]->Reshape(1, channels_, height_, width_);
}

template <typename Dtype>
void MeanExampleLayer<Dtype>::Forward_cpu(const vector<Blob<Dtype>*>& bottom,
      const vector<Blob<Dtype>*>& top) {
  const Dtype* bottom_data = bottom[0]->cpu_data();
  Dtype* top_data = top[0]->mutable_cpu_data();
//  caffe_set(top[0]->count, Dtype(0), top_data);

  const int count = bottom[0]->count();

  for (int i = 0;i < count;++i) {
    const int w = i % width_;
    const int h = (i / width_) % height_;
    const int c = (i / width_ / height_) % channels_;

    top_data[(c * height_ + h) * width_ + w] += bottom_data[i] / num_;
  }
}

template <typename Dtype>
void MeanExampleLayer<Dtype>::Backward_cpu(const vector<Blob<Dtype>*>& top,
      const vector<bool>& propagate_down, const vector<Blob<Dtype>*>& bottom) {
  Dtype* bottom_diff = bottom[0]->mutable_cpu_diff();
  const Dtype* top_diff = top[0]->cpu_diff();

  const int count = bottom[0]->count();
//  caffe_set(count, Dtype(0), bottom_diff);

  for (int i = 0;i < count;++i) {
    const int w = i % width_;
    const int h = (i / width_) % height_;
    const int c = (i / width_ / height_) % channels_;

    bottom_diff[i] = bottom_diff[i] + top_diff[(c * height_ + h) * width_ + w] / num_;
  }
}

#ifdef CPU_ONLY
STUB_GPU(MeanExampleLayer);
#endif

INSTANTIATE_CLASS(MeanExampleLayer);
REGISTER_LAYER_CLASS(MeanExample);

}  // namespace caffe
